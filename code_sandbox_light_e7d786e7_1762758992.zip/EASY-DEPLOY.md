# 🚀 超簡単デプロイガイド（3分で完了）

最も簡単な方法で公開する手順です。

---

## 方法1：Netlify Drop（最も簡単！）

### 📦 必要なもの
- このフォルダ全体
- ブラウザ

### ⚡ 手順（3ステップ）

#### 1️⃣ ファイルをダウンロード
- このページの右上「Publish」タブから全ファイルをダウンロード

#### 2️⃣ Netlify Dropにアクセス
- [https://app.netlify.com/drop](https://app.netlify.com/drop) を開く
- ログイン不要！

#### 3️⃣ ドラッグ&ドロップ
- ダウンロードしたフォルダを画面にドラッグ
- 完成！URLが即座に生成されます

**例**: `https://random-name-123.netlify.app`

---

## 方法2：GitHub Pages（無料・永続）

### 📦 必要なもの
- GitHubアカウント（無料）
- このフォルダ全体

### ⚡ 手順（5ステップ）

#### 1️⃣ GitHubに新規リポジトリ作成
```
https://github.com/new
```
- Repository name: `reishi-ai`
- Public を選択
- 他は全部チェック外す
- 「Create repository」

#### 2️⃣ ファイルをアップロード
- 「uploading an existing file」をクリック
- 全ファイルをドラッグ&ドロップ
- 「Commit changes」

#### 3️⃣ Settings → Pages
- 左メニューの「Pages」
- Branch: `main` を選択
- Save

#### 4️⃣ 完成！
- 2-3分待つ
- `https://あなたのユーザー名.github.io/reishi-ai/`

---

## 🎁 コピペ用ファイル一覧

以下をそのままコピーして新しいフォルダに保存してください：

### 📄 必須ファイル

```
プロジェクトフォルダ/
├── index.html
├── js/
│   ├── config.js
│   ├── bulk-input-parser.js
│   ├── prompt-template.js
│   ├── api-simple.js
│   └── app.js
├── README.md
├── QUICKSTART.md
└── DEPLOY.md
```

---

## 💡 どっちがいい？

| 方法 | 難易度 | 時間 | URL | 推奨度 |
|---|---|---|---|---|
| Netlify Drop | ★☆☆☆☆ | 1分 | ランダム | ⭐⭐⭐⭐⭐ |
| GitHub Pages | ★★☆☆☆ | 3分 | 固定 | ⭐⭐⭐⭐ |

**超初心者向け**: Netlify Drop
**長く使いたい**: GitHub Pages

---

## 🆘 困ったら

### Q: ファイルはどこ？
A: このページ右上の「Publish」タブ

### Q: Netlify Dropでログイン求められる
A: Skip または「Continue without login」

### Q: GitHubでファイルが見えない
A: フォルダ構造を維持してアップロード

### Q: URLを変えたい
A: Netlify → Site settings → Change site name

---

**今すぐ試してみてください！** 🚀