# 🐙 GitHub Pages 完全ガイド

画像を見ながら進められる、超詳しいGitHub公開手順です。

---

## 📋 事前準備

### 必要なもの
- GitHubアカウント（無料）
- このプロジェクトの全ファイル

### 所要時間
- 初めて：10分
- 2回目以降：3分

---

## ステップ1️⃣：GitHubアカウントを作成

### 1-1. GitHubにアクセス

ブラウザで以下を開く：
```
https://github.com
```

### 1-2. サインアップ

- 右上の「Sign up」をクリック
- メールアドレスを入力
- パスワードを作成
- ユーザー名を決める（例：`tanaka-taro`）
- 認証を完了

**すでにアカウントがある場合は「Sign in」でログイン**

---

## ステップ2️⃣：新しいリポジトリを作成

### 2-1. 新規リポジトリ作成ページを開く

ログイン後、以下のURLを開く：
```
https://github.com/new
```

または、右上の「+」ボタン → 「New repository」をクリック

### 2-2. リポジトリの設定

以下を入力してください：

| 項目 | 入力内容 |
|---|---|
| **Repository name** | `reishi-ai` （好きな名前でOK） |
| **Description** | `霊視鑑定AI生成ツール` （省略可） |
| **Public / Private** | **Public** を選択 ✅ |
| **Add a README file** | ✅ **チェックを外す** |
| **Add .gitignore** | 何も選ばない |
| **Choose a license** | None |

### 2-3. 作成

- 一番下の緑色の「**Create repository**」ボタンをクリック

---

## ステップ3️⃣：ファイルをアップロード

### 3-1. アップロードページに移動

リポジトリが作成されたら、ページに表示される：

```
Quick setup — if you've done this kind of thing before
```

その下に「**uploading an existing file**」というリンクがあるので**クリック**

### 3-2. ファイルを準備

以下のファイルとフォルダが必要です：

```
必要なファイル：
✅ index.html
✅ README.md
✅ QUICKSTART.md
✅ DEPLOY.md
✅ EASY-DEPLOY.md
✅ GITHUB-GUIDE.md
✅ .gitignore

✅ js/ フォルダ（以下を含む）
   ├── config.js
   ├── bulk-input-parser.js
   ├── prompt-template.js
   ├── api-simple.js
   └── app.js
```

### 3-3. ファイルをドラッグ&ドロップ

1. 上記の**すべてのファイルとjsフォルダ**を選択
2. ブラウザのアップロード画面にドラッグ&ドロップ
3. ファイル一覧が表示されるのを確認

**⚠️ 注意：jsフォルダの構造が保たれていることを確認してください**

### 3-4. コミット

ページの下の方にスクロールして：

- **Commit message**: `初回コミット` （そのままでOK）
- 緑色の「**Commit changes**」ボタンをクリック

---

## ステップ4️⃣：GitHub Pages を有効化

### 4-1. Settings ページに移動

リポジトリのページで、上部にあるタブから「**Settings**」をクリック

### 4-2. Pages 設定を開く

左側のサイドバーを下にスクロールして「**Pages**」をクリック

### 4-3. ソースを設定

「**Build and deployment**」セクションで：

1. **Source**: 「Deploy from a branch」を選択（デフォルト）
2. **Branch**: 
   - ドロップダウンから「**main**」を選択
   - 隣のドロップダウンは「**/ (root)**」を選択
3. 青い「**Save**」ボタンをクリック

### 4-4. 確認

ページ上部に青い枠で以下のように表示されます：

```
GitHub Pages source saved.
```

その下に緑色の枠で：

```
✅ Your site is live at https://あなたのユーザー名.github.io/reishi-ai/
```

**このURLをコピーしてください！これがあなたのサイトのURLです。**

---

## ステップ5️⃣：公開を確認

### 5-1. 少し待つ

- GitHub Pagesのビルドには**2〜3分**かかります
- 緑色のチェックマークが表示されるまで待ちます

### 5-2. URLにアクセス

ブラウザで以下のURLを開く：
```
https://あなたのユーザー名.github.io/reishi-ai/
```

### 5-3. 動作確認

1. サイトが表示されることを確認
2. 顧客情報を貼り付けてテスト
3. 鑑定文が生成されることを確認

---

## 🎉 完成！

おめでとうございます！あなたの霊視鑑定AIツールが公開されました！

### あなたのURL
```
https://あなたのユーザー名.github.io/reishi-ai/
```

このURLを友人に共有してください。

---

## 📝 ファイルを更新したい場合

### 方法1：Web上で編集

1. GitHubのリポジトリページを開く
2. 編集したいファイル（例：`js/config.js`）をクリック
3. 右上の鉛筆アイコン（Edit）をクリック
4. 内容を編集
5. 下の「Commit changes」をクリック
6. 2〜3分待つと更新が反映されます

### 方法2：ファイルを再アップロード

1. リポジトリページで「Add file」→「Upload files」
2. 更新したいファイルをドラッグ&ドロップ
3. 「Commit changes」をクリック

---

## 🆘 よくあるトラブル

### Q1: 404 Not Found と表示される

**原因**: まだビルド中
**解決**: 5分待ってから再度アクセス

### Q2: ページは表示されるがデザインが崩れている

**原因**: ファイルがすべてアップロードされていない
**解決**: jsフォルダの中身がすべてあるか確認

### Q3: 生成ボタンを押してもエラーになる

**原因**: APIキーの問題
**解決**: 
1. GitHubで `js/config.js` を開く
2. 編集ボタンをクリック
3. APIキーが正しく設定されているか確認
4. 保存

### Q4: URLを変更したい

**方法**:
1. Settings → General
2. 「Repository name」を変更
3. 「Rename」をクリック
4. 新しいURL: `https://ユーザー名.github.io/新しい名前/`

---

## 💡 次のステップ

### カスタムドメインを使いたい

1. 独自ドメイン（例：`reishi-ai.com`）を取得
2. Settings → Pages → Custom domain で設定
3. DNSレコードを設定

### プライベートリポジトリにしたい

1. Settings → General
2. 「Danger Zone」セクション
3. 「Change repository visibility」
4. 「Make private」を選択

**注意**: プライベートにするとGitHub Pagesは有料プランが必要です

---

## 🎓 さらに詳しく知りたい

- [GitHub Pages 公式ドキュメント](https://docs.github.com/ja/pages)
- [Git 入門](https://docs.github.com/ja/get-started)

---

**分からないことがあれば、このガイドを見直してください！**

成功を祈っています！🚀