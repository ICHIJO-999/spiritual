// OpenRouter API通信モジュール（シンプル版）

/**
 * OpenRouter APIを使用して鑑定文を生成
 * @param {Object} formData - フォームデータ
 * @returns {Promise<string>} - 生成された鑑定文
 */
async function generateReadingWithAI(formData) {
    // APIキーの確認
    if (!CONFIG.OPENROUTER_API_KEY || CONFIG.OPENROUTER_API_KEY === 'YOUR_OPENROUTER_API_KEY_HERE') {
        throw new Error('APIキーが設定されていません。js/config.js を編集してAPIキーを設定してください。');
    }

    // プロンプトを生成
    const userPrompt = generateUserPrompt(formData);

    // APIリクエストボディ
    const requestBody = {
        model: CONFIG.MODEL,
        messages: [
            {
                role: 'system',
                content: SYSTEM_PROMPT
            },
            {
                role: 'user',
                content: userPrompt
            }
        ],
        max_tokens: CONFIG.MAX_TOKENS,
        temperature: CONFIG.TEMPERATURE
    };

    try {
        console.log('🔮 AI鑑定文生成を開始...');
        console.log('📝 使用モデル:', CONFIG.MODEL);

        const response = await fetch(CONFIG.API_URL, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${CONFIG.OPENROUTER_API_KEY}`,
                'Content-Type': 'application/json',
                'HTTP-Referer': CONFIG.APP_URL,
                'X-Title': 'Reishi-AI-Tool'
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            console.error('❌ APIエラー:', errorData);
            
            if (response.status === 401) {
                throw new Error('APIキーが無効です。js/config.js のAPIキーを確認してください。');
            } else if (response.status === 429) {
                throw new Error('APIのレート制限に達しました。しばらく待ってから再試行してください。');
            } else if (response.status === 402) {
                throw new Error('OpenRouterのクレジットが不足しています。クレジットをチャージしてください。');
            } else {
                throw new Error(`API呼び出しに失敗しました (ステータス: ${response.status})`);
            }
        }

        const data = await response.json();
        console.log('✅ AI鑑定文生成完了');

        // レスポンスからテキストを抽出
        if (data.choices && data.choices.length > 0) {
            const generatedText = data.choices[0].message.content;
            
            // 使用トークン数をログ出力
            if (data.usage) {
                console.log('📊 使用トークン数:', {
                    prompt: data.usage.prompt_tokens,
                    completion: data.usage.completion_tokens,
                    total: data.usage.total_tokens
                });
            }

            return generatedText;
        } else {
            throw new Error('APIからの応答が空でした。');
        }

    } catch (error) {
        console.error('❌ エラー発生:', error);
        throw error;
    }
}

// エクスポート
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { generateReadingWithAI };
}