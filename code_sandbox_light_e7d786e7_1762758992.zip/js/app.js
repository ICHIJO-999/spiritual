// メインアプリケーションロジック

document.addEventListener('DOMContentLoaded', function() {
    // 文字数カウント
    const bulkInput = document.getElementById('bulkInput');
    const bulkInputCount = document.getElementById('bulkInputCount');
    
    bulkInput.addEventListener('input', function() {
        bulkInputCount.textContent = this.value.length;
    });

    // フォーム送信イベント
    document.getElementById('bulkInputForm').addEventListener('submit', handleFormSubmit);
    
    // コピーボタン
    document.getElementById('copyButton').addEventListener('click', copyToClipboard);
});

// フォーム送信処理
async function handleFormSubmit(e) {
    e.preventDefault();
    
    console.log('🚀 フォーム送信開始');
    
    // 一括入力テキストを取得
    const bulkText = document.getElementById('bulkInput').value;
    
    console.log('📝 入力文字数:', bulkText.length);
    
    if (!bulkText.trim()) {
        alert('顧客情報を入力してください。');
        return;
    }

    // ローディング表示
    showLoading();
    
    console.log('⏳ ローディング表示完了');
    
    try {
        // 顧客情報を解析
        console.log('📝 顧客情報を解析中...');
        const parsedData = parseBulkInput(bulkText);
        
        console.log('🔍 解析結果:', parsedData);
        
        // 検証
        const validation = validateParsedData(parsedData);
        console.log('✓ 検証結果:', validation);
        
        if (!validation.valid) {
            throw new Error('顧客情報の解析に失敗しました: ' + validation.errors.join(', '));
        }
        
        console.log('✅ 解析完了 - API呼び出し開始');
        
        // AI APIを使用して鑑定文を生成
        const generatedText = await generateReadingWithAI(parsedData);
        
        console.log('🎉 生成完了 - 文字数:', generatedText.length);
        
        displayResult(generatedText);
    } catch (error) {
        console.error('❌ エラー発生:', error);
        console.error('❌ エラー詳細:', error.message);
        console.error('❌ スタックトレース:', error.stack);
        showError(error.message);
    } finally {
        hideLoading();
    }
}

// ローディング表示
function showLoading() {
    document.getElementById('loadingSection').classList.remove('hidden');
    document.getElementById('outputSection').classList.add('hidden');
    
    // スクロール
    document.getElementById('loadingSection').scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center' 
    });
}

// ローディング非表示
function hideLoading() {
    document.getElementById('loadingSection').classList.add('hidden');
}

// 結果表示
function displayResult(text) {
    const outputSection = document.getElementById('outputSection');
    const contentDiv = document.getElementById('generatedContent');
    const charCountSpan = document.getElementById('totalCharCount');
    
    // テキストを表示
    contentDiv.textContent = text;
    
    // 文字数をカウント
    const charCount = text.length;
    charCountSpan.textContent = charCount;
    
    // 文字数に応じて色を変更
    if (charCount >= 4500 && charCount <= 5000) {
        charCountSpan.className = 'text-green-400 font-bold text-lg';
    } else if (charCount >= 4000 && charCount <= 5500) {
        charCountSpan.className = 'text-yellow-400 font-bold text-lg';
    } else {
        charCountSpan.className = 'text-red-400 font-bold text-lg';
    }
    
    // 表示
    outputSection.classList.remove('hidden');
    
    // スクロール
    outputSection.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
    });
}

// エラー表示
function showError(message) {
    const outputSection = document.getElementById('outputSection');
    const contentDiv = document.getElementById('generatedContent');
    
    contentDiv.innerHTML = `
        <div class="text-center py-12">
            <div class="text-6xl mb-4">⚠️</div>
            <h3 class="text-2xl font-bold text-red-400 mb-4">エラーが発生しました</h3>
            <p class="text-gray-300 mb-6">${message}</p>
            <div class="bg-yellow-900 bg-opacity-30 border border-yellow-700 rounded-lg p-6 text-left max-w-xl mx-auto">
                <p class="text-sm text-yellow-200 font-semibold mb-3">確認事項：</p>
                <ul class="text-sm text-yellow-100 space-y-2">
                    <li>✓ js/config.js にAPIキーが正しく設定されているか</li>
                    <li>✓ OpenRouterのアカウントに十分なクレジットがあるか</li>
                    <li>✓ インターネット接続が正常か</li>
                    <li>✓ 顧客情報が正しい形式で入力されているか</li>
                </ul>
            </div>
        </div>
    `;
    
    outputSection.classList.remove('hidden');
    outputSection.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
    });
}

// クリップボードにコピー
function copyToClipboard() {
    const content = document.getElementById('generatedContent').textContent;
    
    navigator.clipboard.writeText(content).then(() => {
        const button = document.getElementById('copyButton');
        const originalHTML = button.innerHTML;
        
        button.innerHTML = '<span class="text-xl mr-2">✅</span>コピーしました！';
        button.classList.remove('bg-green-600', 'hover:bg-green-700');
        button.classList.add('bg-blue-600');
        
        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.classList.remove('bg-blue-600');
            button.classList.add('bg-green-600', 'hover:bg-green-700');
        }, 2000);
    }).catch(err => {
        alert('コピーに失敗しました。手動でコピーしてください。');
        console.error('コピーエラー:', err);
    });
}