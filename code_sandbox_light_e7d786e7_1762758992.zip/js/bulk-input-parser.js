// 一括入力解析モジュール

/**
 * 顧客情報の一括入力テキストを解析
 * @param {string} bulkText - 一括入力されたテキスト
 * @returns {Object} - 解析された顧客情報
 */
function parseBulkInput(bulkText) {
    const data = {
        name: '',
        age: '',
        birthdate: '',
        problem: '',
        freeReading: '',
        painfulMoment: '',
        idealFuture: '',
        procrastination: '',
        auraColor: 'ゴールド',
        struggles: '',
        signature: '霊視鑑定師',
        additionalQuestion: ''
    };

    // 改行で分割
    const lines = bulkText.split('\n').map(line => line.trim()).filter(line => line);

    // 1. 名前を抽出（①や「さん」を含む行）
    const nameMatch = bulkText.match(/①\s*([^\s]+\.?[A-Z])\s*(男|女)?/i) || 
                      bulkText.match(/([^\s]+\.?[A-Z])\s*さん/i);
    if (nameMatch) {
        data.name = nameMatch[1].replace(/さん$/, '');
    }

    // 2. 生年月日・年齢を抽出
    const birthdateMatch = bulkText.match(/②\s*(\d{4})\.(\d{1,2})\.(\d{1,2})/);
    if (birthdateMatch) {
        data.birthdate = `${birthdateMatch[1]}.${birthdateMatch[2]}.${birthdateMatch[3]}`;
        const birthYear = parseInt(birthdateMatch[1]);
        const currentYear = new Date().getFullYear();
        data.age = (currentYear - birthYear).toString();
    }

    // 3. 悩み・相談内容を抽出（③以降）
    const problemMatch = bulkText.match(/③([\s\S]*?)(?=⑤|よろしくお願いします|Tsuyoshi\.H\s*さん|$)/);
    if (problemMatch) {
        data.problem = problemMatch[1].trim();
    }

    // 4. 理想の未来を抽出（⑤以降）
    const futureMatch = bulkText.match(/⑤([\s\S]*?)(?=よろしくお願いします|Tsuyoshi\.H\s*さん|$)/);
    if (futureMatch) {
        data.idealFuture = futureMatch[1].trim();
    }

    // 5. 無料鑑定の内容を抽出（より柔軟に）
    // パターン1: ===で囲まれた部分
    let freeReadingMatch = bulkText.match(/={3,}([\s\S]*?)={3,}/);
    if (freeReadingMatch) {
        data.freeReading = freeReadingMatch[1].trim();
    } else {
        // パターン2: 「さん」の後から「実は」「もし」「深層鑑定」の前まで
        freeReadingMatch = bulkText.match(/さん[\s\S]*?(?:大変|お待たせ)([\s\S]*?)(?=実は少し前に|もしご自身の魂|深層鑑定希望|$)/);
        if (freeReadingMatch) {
            data.freeReading = freeReadingMatch[0].trim();
        } else {
            // パターン3: 「よろしくお願いします」の後から最後まで
            freeReadingMatch = bulkText.match(/よろしくお願いします[^\n]*\n([\s\S]+)/);
            if (freeReadingMatch) {
                data.freeReading = freeReadingMatch[1].trim();
            }
        }
    }

    // 6. 最も苦しい瞬間を抽出（無料鑑定から推測）
    const painfulMoments = [
        /今あなたは本当に[^。]*必死に[^。]*立っていらっしゃいますよね/,
        /あなたは今たった一人もがき苦しんでいる/,
        /出口のない暗く冷たいトンネルの中で/
    ];
    
    for (const pattern of painfulMoments) {
        const match = bulkText.match(pattern);
        if (match) {
            data.painfulMoment = match[0];
            break;
        }
    }

    // デフォルトの最も苦しい瞬間（見つからない場合）
    if (!data.painfulMoment && data.problem) {
        const problemLines = data.problem.split('。');
        data.painfulMoment = problemLines.slice(0, 2).join('。') + '。';
    }

    // 7. 先延ばしパターンを抽出
    const procrastinationPatterns = [
        /「([^」]*不安[^」]*)」/,
        /「([^」]*心配[^」]*)」/,
        /「([^」]*どうなる[^」]*)」/
    ];

    for (const pattern of procrastinationPatterns) {
        const match = bulkText.match(pattern);
        if (match) {
            data.procrastination = match[1];
            break;
        }
    }

    // 8. 追加質問を抽出
    const additionalQuestionMatch = bulkText.match(/追加で.*?あればこちらに書いておいて[\s\S]*?(?=こんばんは|少し氣になる|$)/);
    if (additionalQuestionMatch) {
        const afterMatch = bulkText.substring(additionalQuestionMatch.index + additionalQuestionMatch[0].length);
        const questionMatch = afterMatch.match(/こんばんは[\s\S]*?よろしくお願いします/);
        if (questionMatch) {
            data.additionalQuestion = questionMatch[0].trim();
        }
    }

    // 9. オーラの色を推測（問題内容から）
    if (data.problem.includes('お金') || data.problem.includes('仕事') || data.problem.includes('豊か')) {
        data.auraColor = 'ゴールド';
    } else if (data.problem.includes('家族') || data.problem.includes('子ども')) {
        data.auraColor = 'エメラルドグリーン';
    } else if (data.problem.includes('愛') || data.problem.includes('恋')) {
        data.auraColor = 'ローズピンク';
    }

    // 10. 苦労を推測
    if (data.problem.includes('仕事を辞めた') || data.problem.includes('失業')) {
        data.struggles = '長年勤めた仕事を手放す決断をした。\n家族を養う責任を一人で抱えてきた。\n将来への不安と戦いながらも前を向いてきた。';
    }

    return data;
}

/**
 * 解析結果の検証
 * @param {Object} data - 解析されたデータ
 * @returns {Object} - { valid: boolean, errors: string[] }
 */
function validateParsedData(data) {
    const errors = [];
    const warnings = [];

    // 必須項目
    if (!data.name) {
        errors.push('名前が見つかりませんでした');
    }

    if (!data.problem) {
        errors.push('悩み・相談内容が見つかりませんでした');
    }

    // 推奨項目（なくても生成可能）
    if (!data.freeReading) {
        warnings.push('無料鑑定の内容が見つかりませんでした（デフォルト値を使用します）');
        // デフォルト値を設定
        data.freeReading = 'あなたの魂の声に耳を傾けると、本当に求めているものが見えてきます。';
    }

    if (warnings.length > 0) {
        console.warn('⚠️ 警告:', warnings);
    }

    return {
        valid: errors.length === 0,
        errors: errors,
        warnings: warnings
    };
}

// エクスポート
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { parseBulkInput, validateParsedData };
}