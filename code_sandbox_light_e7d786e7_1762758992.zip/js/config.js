// API設定ファイル
// 友人限定公開用：APIキーをここに設定してください

const CONFIG = {
    // OpenRouter API設定
    // https://openrouter.ai/keys でAPIキーを取得してください
    OPENROUTER_API_KEY: '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',
    
    // 使用するモデル（Claude Sonnet 3.5 - 安定版）
    MODEL: 'anthropic/claude-3.5-sonnet',
    
    // API設定
    API_URL: 'https://openrouter.ai/api/v1/chat/completions',
    
    // アプリケーション情報
    APP_NAME: '霊視鑑定【破】AI生成ツール',
    APP_URL: window.location.href,
    
    // 生成パラメータ
    MAX_TOKENS: 8000,        // 最大トークン数
    TEMPERATURE: 0.7         // 創造性（0.0〜1.0）
};

// エクスポート
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CONFIG };
}